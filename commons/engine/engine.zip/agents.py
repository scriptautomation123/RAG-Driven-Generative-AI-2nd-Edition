# === Imports ===
import logging
import json
from helpers import call_llm_robust, create_mcp_message # [FIX] Removed query_pinecone import

# [FIX] Removed Librarian and Researcher (Pinecone-dependent agents)
# This file now strictly contains LLM-only agents.

# === 4.3. Writer Agent ===
def agent_writer(mcp_message, client, generation_model):
    """Combines research with a blueprint to generate the final output."""
    logging.info("[Writer] Activated. Applying blueprint to source material...")
    try:
        blueprint_data = mcp_message['content'].get('blueprint')
        facts_data = mcp_message['content'].get('facts')
        previous_content = mcp_message['content'].get('previous_content')
        
        # If no explicit blueprint is provided, default to a neutral instruction
        if blueprint_data:
            blueprint_json_string = blueprint_data.get('blueprint_json') if isinstance(blueprint_data, dict) else blueprint_data
        else:
             blueprint_json_string = json.dumps({"instruction": "Generate the content neutrally."})

        # FINAL ROBUST LOGIC for handling multiple data contracts
        facts = None
        if isinstance(facts_data, dict):
            # Check for 'facts' (Standard)
            facts = facts_data.get('facts')
            # Check for 'summary' (Summarizer)
            if facts is None:
                facts = facts_data.get('summary')
            # Check for 'retrieved_context' (Oracle Archivist/Recruiter)
            if facts is None:
                facts = facts_data.get('retrieved_context')
                
        elif isinstance(facts_data, str):
            facts = facts_data

        if not blueprint_json_string or (not facts and not previous_content):
            # If we have no facts, we can try to proceed if we have a goal, 
            # but strictly speaking, the writer needs raw material.
            # For this simplified engine, we will allow 'facts' to be optional if 'previous_content' exists.
            if not previous_content:
                 raise ValueError("Writer requires 'facts' (or retrieved_context) or 'previous_content'.")

        if facts:
            source_material = facts
            source_label = "SOURCE MATERIAL"
        else:
            source_material = previous_content
            source_label = "PREVIOUS CONTENT (For Rewriting)"

        system_prompt = f"""You are an expert content generation AI. Your task is to generate or rewrite content based on the provided SOURCE MATERIAL. If a blueprint is provided, follow it."""
        
        user_prompt = f"""--- SEMANTIC BLUEPRINT (JSON) ---\n{blueprint_json_string}\n\n--- SOURCE MATERIAL ({source_label}) ---\n{source_material}\n\nGenerate the final content now."""

        final_output = call_llm_robust(
            system_prompt,
            user_prompt,
            client=client,
            generation_model=generation_model
        )
        return create_mcp_message("Writer", final_output)
        
    except Exception as e:
        logging.error(f"[Writer] An error occurred: {e}")
        raise e

# === 4.4. Summarizer Agent ===
def agent_summarizer(mcp_message, client, generation_model):
    """
    Reduces a large text to a concise summary based on an objective.
    """
    logging.info("[Summarizer] Activated. Reducing context...")
    try:
        text_to_summarize = mcp_message['content'].get('text_to_summarize')
        summary_objective = mcp_message['content'].get('summary_objective')

        if not text_to_summarize or not summary_objective:
            raise ValueError("Summarizer requires 'text_to_summarize' and 'summary_objective'.")

        system_prompt = """You are an expert summarization AI. Reduce the text to essential points."""
        user_prompt = f"""--- OBJECTIVE ---
{summary_objective}

--- TEXT TO SUMMARIZE ---
{text_to_summarize}
--- END TEXT ---

Generate the summary now."""

        summary = call_llm_robust(
            system_prompt,
            user_prompt,
            client=client,
            generation_model=generation_model
        )

        return create_mcp_message("Summarizer", {"summary": summary})
    except Exception as e:
        logging.error(f"[Summarizer] An error occurred: {e}")
        raise e
        
logging.info("✅ Standard LLM Agents defined.")